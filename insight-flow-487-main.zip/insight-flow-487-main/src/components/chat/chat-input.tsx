"use client";
import { Paperclip, Mic, ArrowUp, Square } from "lucide-react";
import { useState, type KeyboardEvent } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";

interface Props {
  onSend: (value: string) => void;
  onStop?: () => void;
  loading?: boolean;
  placeholder?: string;
}

export function ChatInput({ onSend, onStop, loading, placeholder = "Ask anything about your documents…" }: Props) {
  const [value, setValue] = useState("");

  const submit = () => {
    if (!value.trim() || loading) return;
    onSend(value.trim());
    setValue("");
  };

  const onKey = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      submit();
    }
  };

  return (
    <div className="rounded-2xl border border-border bg-card shadow-sm transition-shadow focus-within:shadow-md">
      <Textarea
        value={value}
        onChange={(e) => setValue(e.target.value)}
        onKeyDown={onKey}
        rows={1}
        placeholder={placeholder}
        className="scrollbar-thin max-h-44 min-h-[52px] resize-none border-0 bg-transparent px-4 py-3.5 text-sm shadow-none focus-visible:ring-0"
      />
      <div className="flex items-center justify-between gap-2 px-2.5 pb-2.5">
        <div className="flex items-center gap-0.5">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-lg text-muted-foreground">
            <Paperclip className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-lg text-muted-foreground">
            <Mic className="h-4 w-4" />
          </Button>
        </div>
        {loading ? (
          <Button size="icon" variant="secondary" onClick={onStop} className="h-8 w-8 rounded-lg">
            <Square className="h-3.5 w-3.5 fill-current" />
          </Button>
        ) : (
          <Button
            size="icon"
            onClick={submit}
            disabled={!value.trim()}
            className={cn("h-8 w-8 rounded-lg")}
          >
            <ArrowUp className="h-4 w-4" />
          </Button>
        )}
      </div>
    </div>
  );
}
