"use client";
import { useNavigate } from "@tanstack/react-router";
import { FileText, FolderKanban, Database } from "lucide-react";
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { mockProjects, mockCRMRecords, mockDocuments } from "@/lib/mock-data";
import { useEffect } from "react";

export function GlobalSearch({ open, onOpenChange }: { open: boolean; onOpenChange: (o: boolean) => void }) {
  const navigate = useNavigate();

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        onOpenChange(!open);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onOpenChange]);

  const go = (path: string) => {
    onOpenChange(false);
    navigate({ to: path });
  };

  return (
    <CommandDialog open={open} onOpenChange={onOpenChange}>
      <CommandInput placeholder="Search projects, documents, CRM records…" />
      <CommandList>
        <CommandEmpty>No results found.</CommandEmpty>
        <CommandGroup heading="Projects">
          {mockProjects.map((p) => (
            <CommandItem key={p.id} onSelect={() => go(`/projects/${p.id}`)}>
              <FolderKanban className="mr-2 h-4 w-4" />
              <span>{p.name}</span>
            </CommandItem>
          ))}
        </CommandGroup>
        <CommandGroup heading="Documents">
          {mockDocuments.map((d) => (
            <CommandItem key={d.id} onSelect={() => go(`/projects/${d.projectId}`)}>
              <FileText className="mr-2 h-4 w-4" />
              <span>{d.name}</span>
            </CommandItem>
          ))}
        </CommandGroup>
        <CommandGroup heading="CRM Records">
          {mockCRMRecords.map((r) => (
            <CommandItem key={r.id} onSelect={() => go(`/crm/${r.id}`)}>
              <Database className="mr-2 h-4 w-4" />
              <span>{r.document}</span>
            </CommandItem>
          ))}
        </CommandGroup>
      </CommandList>
    </CommandDialog>
  );
}
