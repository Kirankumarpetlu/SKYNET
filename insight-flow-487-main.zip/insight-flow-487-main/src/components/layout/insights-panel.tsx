"use client";
import { motion } from "framer-motion";
import { ChevronRight, PanelRightClose, PanelRightOpen } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { RiskCard } from "@/components/cards/risk-card";
import { AnomalyCard } from "@/components/cards/anomaly-card";
import { cn } from "@/lib/utils";

interface Props {
  projectName?: string;
  riskScore?: number;
  documentCount?: number;
}

export function InsightsPanel({ projectName, riskScore = 72, documentCount = 8 }: Props) {
  const [open, setOpen] = useState(true);

  return (
    <>
      {!open && (
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setOpen(true)}
          className="absolute right-3 top-3 z-10 h-8 w-8 rounded-lg border border-border bg-card shadow-sm"
        >
          <PanelRightOpen className="h-4 w-4" />
        </Button>
      )}
      <motion.aside
        animate={{ width: open ? 360 : 0, opacity: open ? 1 : 0 }}
        transition={{ type: "spring", stiffness: 280, damping: 32 }}
        className={cn("hidden h-full shrink-0 overflow-hidden border-l border-border bg-background lg:block")}
      >
        <div className="flex h-full w-[360px] flex-col">
          <div className="flex h-14 items-center justify-between border-b border-border px-4">
            <div>
              <div className="text-sm font-semibold">Project Insights</div>
              {projectName && <div className="truncate text-[11px] text-muted-foreground">{projectName}</div>}
            </div>
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setOpen(false)}>
              <PanelRightClose className="h-4 w-4" />
            </Button>
          </div>

          <div className="scrollbar-thin flex-1 space-y-4 overflow-y-auto p-4">
            <RiskCard score={riskScore} />

            <div className="grid grid-cols-2 gap-3">
              <Stat label="Documents" value={documentCount} />
              <Stat label="Processing" value="2" hint="in pipeline" />
              <Stat label="Critical" value="1" tone="destructive" />
              <Stat label="Warnings" value="3" tone="warning" />
            </div>

            <AnomalyCard />

            <div className="rounded-2xl border border-border bg-card p-4">
              <h3 className="mb-2 text-sm font-semibold">Recent Activity</h3>
              <ul className="space-y-2.5">
                {[
                  { t: "MSA processed", time: "2m ago" },
                  { t: "Risk re-scored", time: "1h ago" },
                  { t: "Synced to CRM", time: "3h ago" },
                  { t: "3 documents uploaded", time: "Yesterday" },
                ].map((a) => (
                  <li key={a.t} className="flex items-center gap-2 text-xs">
                    <ChevronRight className="h-3 w-3 text-muted-foreground" />
                    <span className="flex-1">{a.t}</span>
                    <span className="text-[11px] text-muted-foreground">{a.time}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </motion.aside>
    </>
  );
}

function Stat({ label, value, hint, tone }: { label: string; value: string | number; hint?: string; tone?: "destructive" | "warning" }) {
  return (
    <div className="rounded-xl border border-border bg-card p-3">
      <div className="text-[11px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div
        className={cn(
          "mt-1 text-xl font-semibold",
          tone === "destructive" && "text-destructive",
          tone === "warning" && "text-warning-foreground",
        )}
      >
        {value}
      </div>
      {hint && <div className="text-[11px] text-muted-foreground">{hint}</div>}
    </div>
  );
}
