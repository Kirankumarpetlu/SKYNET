import { createFileRoute, notFound } from "@tanstack/react-router";
import { useState, useEffect, useRef } from "react";
import {
  Upload,
  Share2,
  MoreHorizontal,
  FileText,
  Sparkles,
  ArrowLeft,
} from "lucide-react";
import { Link } from "@tanstack/react-router";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { mockProjects, mockMessages, suggestedPrompts, type ChatMessage as ChatMsg } from "@/lib/mock-data";
import { ChatMessage, TypingIndicator } from "@/components/chat/chat-message";
import { ChatInput } from "@/components/chat/chat-input";
import { UploadZone } from "@/components/upload/upload-zone";
import { ProcessingTimeline } from "@/components/timeline/processing-timeline";
import { InsightsPanel } from "@/components/layout/insights-panel";
import { ClauseList } from "@/components/cards/clause-list";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/projects/$id")({
  loader: ({ params }) => {
    const project = mockProjects.find((p) => p.id === params.id);
    if (!project) throw notFound();
    return { project };
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.project.name ?? "Project"} — Lumen` },
      { name: "description", content: loaderData?.project.description ?? "" },
    ],
  }),
  component: ProjectWorkspace,
});

function ProjectWorkspace() {
  const { project } = Route.useLoaderData();
  const [messages, setMessages] = useState<ChatMsg[]>(mockMessages);
  const [loading, setLoading] = useState(false);
  const [uploadOpen, setUploadOpen] = useState(false);
  const [stage, setStage] = useState(8); // start "complete"; resets when upload runs
  const [tab, setTab] = useState("chat");
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, loading]);

  const send = (text: string) => {
    const userMsg: ChatMsg = {
      id: `m-${Date.now()}`,
      role: "user",
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };
    setMessages((m) => [...m, userMsg]);
    setLoading(true);
    setTimeout(() => {
      const reply: ChatMsg = {
        id: `m-${Date.now()}-r`,
        role: "assistant",
        content: `Here's what I found across your documents based on **"${text}"**:

- Three primary references were identified across **MSA_Acme_2024_Final.pdf** and **Amendment_2.pdf**
- The most relevant clause appears on page 4 with a confidence of **94%**
- I detected one potential inconsistency between the master agreement and the latest amendment

Would you like me to generate a full comparison report?`,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };
      setMessages((m) => [...m, reply]);
      setLoading(false);
    }, 1400);
  };

  const onUploaded = () => {
    setStage(0);
    let s = 0;
    const t = setInterval(() => {
      s += 1;
      setStage(s);
      if (s >= 8) clearInterval(t);
    }, 900);
  };

  return (
    <div className="flex h-full">
      {/* Center workspace */}
      <div className="flex min-w-0 flex-1 flex-col">
        {/* Project header */}
        <div className="flex h-16 shrink-0 items-center justify-between border-b border-border px-6">
          <div className="flex min-w-0 items-center gap-3">
            <Link to="/projects" className="rounded-md p-1 text-muted-foreground hover:bg-muted">
              <ArrowLeft className="h-4 w-4" />
            </Link>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h1 className="truncate text-base font-semibold">{project.name}</h1>
                <span className="rounded-full bg-success/10 px-2 py-0.5 text-[10px] font-medium capitalize text-success">
                  {project.status}
                </span>
              </div>
              <div className="text-[11px] text-muted-foreground">
                {project.documentCount} documents · Updated {project.updatedAt}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <Button size="sm" variant="outline" className="rounded-lg" onClick={() => setUploadOpen(true)}>
              <Upload className="mr-1.5 h-3.5 w-3.5" />
              Upload
            </Button>
            <Button size="sm" variant="ghost" className="rounded-lg">
              <Share2 className="mr-1.5 h-3.5 w-3.5" />
              Share
            </Button>
            <Button size="icon" variant="ghost" className="h-8 w-8 rounded-lg">
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Tabs */}
        <Tabs value={tab} onValueChange={setTab} className="flex min-h-0 flex-1 flex-col">
          <div className="border-b border-border px-6">
            <TabsList className="h-10 bg-transparent p-0">
              <TabsTrigger value="chat" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none">
                Chat
              </TabsTrigger>
              <TabsTrigger value="documents" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none">
                Documents
              </TabsTrigger>
              <TabsTrigger value="clauses" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none">
                Clauses
              </TabsTrigger>
              <TabsTrigger value="pipeline" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none">
                Pipeline
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="chat" className="m-0 flex min-h-0 flex-1 flex-col">
            <div ref={scrollRef} className="scrollbar-thin flex-1 overflow-y-auto">
              <div className="mx-auto max-w-3xl px-6 py-6">
                {messages.length === 0 ? (
                  <WelcomeScreen onPrompt={send} />
                ) : (
                  <div className="space-y-1">
                    <AnimatePresence>
                      {messages.map((m) => (
                        <ChatMessage key={m.id} message={m} />
                      ))}
                    </AnimatePresence>
                    {loading && <TypingIndicator />}
                  </div>
                )}
              </div>
            </div>
            <div className="border-t border-border bg-background/80 backdrop-blur">
              <div className="mx-auto max-w-3xl px-6 py-4">
                <ChatInput onSend={send} loading={loading} onStop={() => setLoading(false)} />
                <p className="mt-2 text-center text-[10px] text-muted-foreground">
                  Lumen can make mistakes — verify critical extractions.
                </p>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="documents" className="scrollbar-thin m-0 flex-1 overflow-y-auto">
            <div className="mx-auto max-w-4xl space-y-6 px-6 py-6">
              <UploadZone onUploaded={onUploaded} />
              <div>
                <h3 className="mb-3 text-sm font-semibold">Project documents</h3>
                <div className="space-y-2">
                  {Array.from({ length: 4 }).map((_, i) => (
                    <DocRow key={i} index={i} />
                  ))}
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="clauses" className="scrollbar-thin m-0 flex-1 overflow-y-auto">
            <div className="mx-auto max-w-3xl px-6 py-6">
              <div className="mb-4">
                <h3 className="text-sm font-semibold">Extracted clauses</h3>
                <p className="text-xs text-muted-foreground">Click a clause to view extracted text and source.</p>
              </div>
              <ClauseList />
            </div>
          </TabsContent>

          <TabsContent value="pipeline" className="scrollbar-thin m-0 flex-1 overflow-y-auto">
            <div className="mx-auto max-w-2xl px-6 py-6">
              <ProcessingTimeline current={stage} />
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Right insights */}
      <InsightsPanel projectName={project.name} riskScore={project.riskScore} documentCount={project.documentCount} />

      {/* Upload modal */}
      <Dialog open={uploadOpen} onOpenChange={setUploadOpen}>
        <DialogContent className="sm:max-w-[560px]">
          <DialogHeader>
            <DialogTitle>Upload documents</DialogTitle>
          </DialogHeader>
          <UploadZone
            onUploaded={() => {
              onUploaded();
              setTab("pipeline");
            }}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}

function WelcomeScreen({ onPrompt }: { onPrompt: (s: string) => void }) {
  return (
    <div className="flex flex-col items-center pt-10 text-center">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="relative"
      >
        <div className="absolute inset-0 -z-10 rounded-full bg-primary/20 blur-3xl" />
        <div className="flex h-16 w-16 items-center justify-center rounded-2xl border border-border bg-card shadow-sm">
          <Sparkles className="h-7 w-7 text-primary" />
        </div>
      </motion.div>
      <h2 className="mt-6 text-xl font-semibold tracking-tight">Upload documents to begin</h2>
      <p className="mt-2 max-w-md text-sm text-muted-foreground">
        Drop contracts, invoices, or statements. Lumen will OCR, classify, and let you ask
        questions in natural language.
      </p>
      <div className="mt-8 grid w-full max-w-xl grid-cols-1 gap-2 sm:grid-cols-2">
        {suggestedPrompts.map((p) => (
          <button
            key={p}
            onClick={() => onPrompt(p)}
            className={cn(
              "group rounded-xl border border-border bg-card px-4 py-3 text-left text-sm transition-all hover:border-primary/40 hover:shadow-sm",
            )}
          >
            <span className="text-muted-foreground transition-colors group-hover:text-foreground">{p}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

function DocRow({ index }: { index: number }) {
  const docs = [
    { name: "MSA_Acme_2024_Final.pdf", size: "2.4 MB", status: "Indexed" },
    { name: "Statement_of_Work_01.docx", size: "812 KB", status: "Indexed" },
    { name: "Pricing_Schedule.xlsx", size: "156 KB", status: "Processing" },
    { name: "Amendment_2.pdf", size: "1.1 MB", status: "Indexed" },
  ];
  const d = docs[index];
  return (
    <div className="flex items-center gap-3 rounded-xl border border-border bg-card p-3 transition-colors hover:border-primary/30">
      <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-muted text-muted-foreground">
        <FileText className="h-4 w-4" />
      </div>
      <div className="min-w-0 flex-1">
        <div className="truncate text-sm font-medium">{d.name}</div>
        <div className="text-[11px] text-muted-foreground">{d.size} · Uploaded 2h ago</div>
      </div>
      <span className={cn("rounded-full px-2 py-0.5 text-[10px] font-medium", d.status === "Indexed" ? "bg-success/10 text-success" : "bg-warning/15 text-warning-foreground")}>
        {d.status}
      </span>
    </div>
  );
}
