import { createFileRoute, notFound, Link } from "@tanstack/react-router";
import { ArrowLeft, ExternalLink, FileText, AlertTriangle, Check, GitCompare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { mockCRMRecords, type RiskLevel } from "@/lib/mock-data";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/crm/$id")({
  loader: ({ params }) => {
    const record = mockCRMRecords.find((r) => r.id === params.id);
    if (!record) throw notFound();
    return { record };
  },
  head: ({ loaderData }) => ({
    meta: [{ title: `${loaderData?.record.document ?? "Record"} — Lumen CRM` }],
  }),
  component: CRMDetail,
});

const riskTone: Record<RiskLevel, string> = {
  low: "bg-success/10 text-success",
  medium: "bg-warning/15 text-warning-foreground",
  high: "bg-destructive/10 text-destructive",
};

function CRMDetail() {
  const { record } = Route.useLoaderData() as { record: (typeof mockCRMRecords)[number] };

  return (
    <div className="scrollbar-thin h-full overflow-y-auto">
      <div className="mx-auto max-w-5xl px-6 py-8">
        <Link to="/crm" className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-3.5 w-3.5" /> Back to records
        </Link>

        <div className="mt-4 flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div className="flex items-start gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
              <FileText className="h-5 w-5" />
            </div>
            <div>
              <h1 className="text-xl font-semibold">{record.document}</h1>
              <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                <span>{record.type}</span>
                <span>·</span>
                <span>Vendor: {record.vendor}</span>
                <span>·</span>
                <span>Processed {record.processedDate}</span>
                <span className={cn("rounded-full px-2 py-0.5 text-[10px] font-medium capitalize", riskTone[record.risk])}>
                  {record.risk} risk
                </span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="rounded-lg">
              <GitCompare className="mr-1.5 h-3.5 w-3.5" />
              Compare
            </Button>
            <Button size="sm" className="rounded-lg">
              <ExternalLink className="mr-1.5 h-3.5 w-3.5" />
              Open in Notion
            </Button>
          </div>
        </div>

        <div className="mt-8 grid grid-cols-1 gap-4 lg:grid-cols-3">
          <Card title="Summary" className="lg:col-span-2">
            <p className="text-sm leading-relaxed text-muted-foreground">{record.summary}</p>
          </Card>

          <Card title="Sync status">
            <div className="space-y-3">
              <Row label="CRM" value="Synced" tone="success" />
              <Row label="Notion" value="Connected" tone="success" />
              <Row label="Last sync" value={record.processedDate} />
            </div>
          </Card>

          <Card title="Parties" className="lg:col-span-2">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <div className="text-[11px] uppercase tracking-wider text-muted-foreground">Vendor</div>
                <div className="mt-0.5 text-sm font-medium">{record.vendor}</div>
              </div>
              <div>
                <div className="text-[11px] uppercase tracking-wider text-muted-foreground">Customer</div>
                <div className="mt-0.5 text-sm font-medium">{record.customer}</div>
              </div>
            </div>
          </Card>

          <Card title="Document">
            <div className="rounded-lg border border-border bg-muted/30 p-4 text-center">
              <FileText className="mx-auto h-8 w-8 text-muted-foreground" />
              <div className="mt-2 text-xs text-muted-foreground">Preview unavailable</div>
              <Button variant="outline" size="sm" className="mt-3 rounded-lg">View original</Button>
            </div>
          </Card>

          <Card title="Issues & flags" className="lg:col-span-3">
            {record.issues.length === 0 ? (
              <div className="flex items-center gap-2 text-sm text-success">
                <Check className="h-4 w-4" /> No issues detected
              </div>
            ) : (
              <ul className="space-y-2">
                {record.issues.map((i: string) => (
                  <li key={i} className="flex items-start gap-2 rounded-lg border border-border bg-card p-3 text-sm">
                    <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-warning-foreground" />
                    <span>{i}</span>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}

function Card({ title, children, className }: { title: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={cn("rounded-2xl border border-border bg-card p-5", className)}>
      <h3 className="mb-3 text-sm font-semibold">{title}</h3>
      {children}
    </div>
  );
}

function Row({ label, value, tone }: { label: string; value: string; tone?: "success" }) {
  return (
    <div className="flex items-center justify-between text-sm">
      <span className="text-muted-foreground">{label}</span>
      <span className={cn("font-medium", tone === "success" && "text-success")}>{value}</span>
    </div>
  );
}
