import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { FolderKanban, Plus, LayoutGrid, List } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { mockProjects } from "@/lib/mock-data";
import { ProjectCard } from "@/components/projects/project-card";
import { NewProjectDialog } from "@/components/projects/new-project-dialog";
import { EmptyState } from "@/components/common/empty-state";

export const Route = createFileRoute("/projects/")({
  component: ProjectsPage,
  head: () => ({
    meta: [
      { title: "Projects — Lumen" },
      { name: "description", content: "All your document intelligence projects." },
    ],
  }),
});

function ProjectsPage() {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");

  const filtered = mockProjects.filter(
    (p) =>
      p.name.toLowerCase().includes(query.toLowerCase()) ||
      p.description.toLowerCase().includes(query.toLowerCase()),
  );

  return (
    <div className="scrollbar-thin h-full overflow-y-auto">
      <div className="mx-auto max-w-7xl px-6 py-10 lg:px-10">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">Projects</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Group documents into focused workspaces. {mockProjects.length} total.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex rounded-lg border border-border bg-card p-0.5">
              <Button size="icon" variant="ghost" className="h-7 w-7 bg-muted">
                <LayoutGrid className="h-3.5 w-3.5" />
              </Button>
              <Button size="icon" variant="ghost" className="h-7 w-7">
                <List className="h-3.5 w-3.5" />
              </Button>
            </div>
            <Button onClick={() => setOpen(true)} className="rounded-lg" size="sm">
              <Plus className="mr-1.5 h-4 w-4" />
              New Project
            </Button>
          </div>
        </div>

        <div className="mt-6 max-w-md">
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search projects…"
            className="h-9 rounded-lg bg-card"
          />
        </div>

        {filtered.length > 0 ? (
          <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
            {filtered.map((p, i) => (
              <ProjectCard key={p.id} project={p} index={i} />
            ))}
          </div>
        ) : (
          <EmptyState
            icon={FolderKanban}
            title="No projects yet"
            description="Create your first project to start uploading and analyzing documents."
            action={{ label: "Create project", onClick: () => setOpen(true) }}
          />
        )}
      </div>
      <NewProjectDialog open={open} onOpenChange={setOpen} />
    </div>
  );
}
