import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Search, SlidersHorizontal, Database } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { mockCRMRecords, type RiskLevel } from "@/lib/mock-data";
import { cn } from "@/lib/utils";
import { EmptyState } from "@/components/common/empty-state";

export const Route = createFileRoute("/crm/")({
  head: () => ({
    meta: [
      { title: "CRM Records — Lumen" },
      { name: "description", content: "Synced document intelligence records." },
    ],
  }),
  component: CRMPage,
});

const riskTone: Record<RiskLevel, string> = {
  low: "bg-success/10 text-success",
  medium: "bg-warning/15 text-warning-foreground",
  high: "bg-destructive/10 text-destructive",
};

const statusTone = {
  synced: "bg-success/10 text-success",
  pending: "bg-warning/15 text-warning-foreground",
  failed: "bg-destructive/10 text-destructive",
} as const;

function CRMPage() {
  const [q, setQ] = useState("");
  const [risk, setRisk] = useState<string>("all");
  const [vendor, setVendor] = useState<string>("all");

  const vendors = Array.from(new Set(mockCRMRecords.map((r) => r.vendor)));

  const filtered = mockCRMRecords.filter((r) => {
    if (q && !r.document.toLowerCase().includes(q.toLowerCase()) && !r.vendor.toLowerCase().includes(q.toLowerCase())) return false;
    if (risk !== "all" && r.risk !== risk) return false;
    if (vendor !== "all" && r.vendor !== vendor) return false;
    return true;
  });

  return (
    <div className="scrollbar-thin h-full overflow-y-auto">
      <div className="mx-auto max-w-7xl px-6 py-10 lg:px-10">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">CRM Records</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            All processed documents synced to your records workspace.
          </p>
        </div>

        <div className="mt-6 flex flex-wrap items-center gap-2">
          <div className="relative max-w-sm flex-1">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search records…"
              className="h-9 rounded-lg bg-card pl-8"
            />
          </div>
          <Select value={risk} onValueChange={setRisk}>
            <SelectTrigger className="h-9 w-[140px] rounded-lg bg-card">
              <SelectValue placeholder="Risk" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All risk</SelectItem>
              <SelectItem value="low">Low</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="high">High</SelectItem>
            </SelectContent>
          </Select>
          <Select value={vendor} onValueChange={setVendor}>
            <SelectTrigger className="h-9 w-[180px] rounded-lg bg-card">
              <SelectValue placeholder="Vendor" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All vendors</SelectItem>
              {vendors.map((v) => (
                <SelectItem key={v} value={v}>{v}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button variant="outline" size="sm" className="h-9 rounded-lg">
            <SlidersHorizontal className="mr-1.5 h-3.5 w-3.5" />
            More filters
          </Button>
        </div>

        {filtered.length > 0 ? (
          <div className="mt-6 overflow-hidden rounded-2xl border border-border bg-card">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border text-left text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                  <th className="px-4 py-3">Document</th>
                  <th className="px-4 py-3">Vendor</th>
                  <th className="px-4 py-3">Type</th>
                  <th className="px-4 py-3">Risk</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">Processed</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((r) => (
                  <tr key={r.id} className="border-b border-border last:border-0 transition-colors hover:bg-muted/40">
                    <td className="px-4 py-3">
                      <Link to="/crm/$id" params={{ id: r.id }} className="font-medium hover:text-primary">
                        {r.document}
                      </Link>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{r.vendor}</td>
                    <td className="px-4 py-3 text-muted-foreground">{r.type}</td>
                    <td className="px-4 py-3">
                      <span className={cn("rounded-full px-2 py-0.5 text-[10px] font-medium capitalize", riskTone[r.risk])}>
                        {r.risk}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className={cn("rounded-full px-2 py-0.5 text-[10px] font-medium capitalize", statusTone[r.status])}>
                        {r.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{r.processedDate}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState icon={Database} title="No records match" description="Try adjusting your filters or search." />
        )}
      </div>
    </div>
  );
}
